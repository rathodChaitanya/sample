// int n = 10, firstTerm = 0, secondTerm = 1;
// System.out.println("Fibonacci Series till " + n + " terms:");

// for (int i = 1; i <= n; ++i) {
//   System.out.print(firstTerm + ", ");

//   // compute the next term
//   int nextTerm = firstTerm + secondTerm;
//   firstTerm = secondTerm;
//   secondTerm = nextTerm;
// }
var fs = require("fs")
var num =100
var fn =0
var sn =1

for (let i = 0; i < 100; i++) {
    fn
    fs.appendFileSync("fib.txt",fn.toString()+"\n")
    var nn=fn+sn
    fn=sn
    sn=nn
}