var fs = require("fs")

// var read = fs.readFile('read.txt','utf8', function(err, data))
// console.log(read)
// fs.readFile('read.txt', 'utf8', function(err, data){
//         console.log(data);
//     });

var c = fs.readFileSync("read.txt")
var d =c.toString();
var array =d.split(",");
var sum=0;
for (let i = 0; i < array.length; i++) {
    sum =  sum + parseInt(array[i])   
}
fs.writeFileSync("res.txt",sum.toString())




