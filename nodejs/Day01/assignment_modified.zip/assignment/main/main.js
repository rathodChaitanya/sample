var x =require("./time")
x.greet()