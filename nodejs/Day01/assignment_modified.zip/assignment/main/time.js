var fs = require('fs');
 var myDate = new Date();
 var hrs = myDate.getHours();

exports.greet = function(){
    if (hrs < 12) {
        var str = "Good Morning"
        fs.writeFileSync("demo.txt",str)
    } else if(hrs >= 12 && hrs <= 17){
        var str = "Good Afternoon"
        fs.writeFileSync("demo.txt",str)
    }else if(hrs >=17 && hrs <= 24){
        var str = "Good Evening"
        fs.writeFileSync("demo.txt",str)
    }
    
}