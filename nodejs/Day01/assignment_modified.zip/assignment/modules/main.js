var fs = require("fs")
var a = require("./read")
var str =a.name
fs.appendFileSync("dummy.txt",str)//append into the file
