var data={
    name : "chaitanya",
}

module.exports = data